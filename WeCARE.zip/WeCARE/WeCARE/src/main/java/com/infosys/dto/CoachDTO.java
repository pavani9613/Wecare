package com.infosys.dto;

import java.time.LocalDate;

import javax.validation.constraints.Digits;
//import javax.validation.constraints.Max;
//import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import com.infosys.entity.CoachEntity;




public class CoachDTO {
	
	
	private String coachId;
	
	@NotNull(message = "Name cannot be empty")
	@Length(min = 3, max = 50, message = "name should be min 3 and max 50")
	private String name;
	
	@NotNull(message = "Password cannot be empty")
	@Length(min = 5, max = 10, message = "password should be min 5 and max 10")
	private String password;
	
	private char gender;
	private LocalDate dateOfBirth;
	
	@NotNull(message = "Mobile no can't be blank")
	@Digits(integer = 10, message = "min and max should be 10", fraction = 0)
	private long mobileNumber;
	
	@NotNull(message = "Speciality no can't be blank")
	@Length(min = 3, max = 50, message = "speciality should be min 3 and max 50")
	private String speciality;

	public CoachDTO() { } 
	
	public CoachDTO(String coachId, String name, String password, char gender, LocalDate dateOfBirth, long mobileNumber,
			String speciality) {
		super();
		this.coachId = coachId;
		this.name = name;
		this.password = password;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.mobileNumber = mobileNumber;
		this.speciality = speciality;
	}

	public String getCoachId() {
		return coachId;
	}

	public void setCoachId(String coachId) {
		this.coachId = coachId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
	
	public static CoachEntity prepareCoachEntity(CoachDTO coachDTO)
	{
		CoachEntity coachEntity = new CoachEntity();
		coachEntity.setCoachId(coachDTO.getCoachId());
		coachEntity.setDateOfBirth(coachDTO.getDateOfBirth());
		coachEntity.setGender(coachDTO.getGender());
		coachEntity.setMobileNumber(coachDTO.getMobileNumber());
		coachEntity.setName(coachDTO.getName());
		coachEntity.setPassword(coachDTO.getPassword());
		coachEntity.setSpeciality(coachDTO.getSpeciality());
		
		return coachEntity;
	}

	@Override
	public String toString() {
		return "CoachDTO [coachId=" + coachId + ", name=" + name + ", password=" + password + ", gender=" + gender
				+ ", dateOfBirth=" + dateOfBirth + ", mobileNumber=" + mobileNumber + ", speciality=" + speciality
				+ "]";
	}

	
}
