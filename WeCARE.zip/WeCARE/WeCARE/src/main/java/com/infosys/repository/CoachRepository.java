package com.infosys.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.entity.CoachEntity;

public interface CoachRepository extends JpaRepository<CoachEntity, String>
{

	public Optional<CoachEntity> findByCoachId(String coachId);

}
