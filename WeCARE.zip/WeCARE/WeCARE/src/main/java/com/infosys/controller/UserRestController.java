package com.infosys.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.BookingDTO;
import com.infosys.dto.ErrorMessage;
import com.infosys.dto.LoginDTO;
import com.infosys.dto.UserDTO;
import com.infosys.exception.WecareException;
import com.infosys.service.BookService;
import com.infosys.service.UserService;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserRestController {

	private static Logger logger = LoggerFactory.getLogger(UserRestController.class);

	@Autowired
	private UserService userService;
	
	@Autowired
	private BookService bookService;

	@PostMapping
	public ResponseEntity<String> createUser(@RequestBody UserDTO userDTO, Errors error) {

		logger.info("In createUser method");

		String response = "";
		if (error.hasErrors()) {
			// collecting the validation errors of all fields together in a String delimited
			// by commas
			response = error.getAllErrors().stream().map(ObjectError::getDefaultMessage)
					.collect(Collectors.joining(","));
			ErrorMessage er = new ErrorMessage();
			er.setMessage(response);
			return ResponseEntity.ok(er.getMessage());
		} else {
			response = userService.createUser(userDTO);
			return ResponseEntity.ok(response);
		}
	}

	@PostMapping("/login")
	public ResponseEntity<Boolean> loginUser(@RequestBody LoginDTO loginDTO) throws WecareException {

		logger.info("In loginUser method");
		boolean response = false;

		response = userService.loginUser(loginDTO);
		System.out.println(response);
		return ResponseEntity.ok(response);
	}

	@GetMapping("/{userId}")
	public ResponseEntity<UserDTO> getUserProfile(@PathVariable("userId") String userId) {
		
		logger.info("In getUserProfile method");
		UserDTO userDTO = new UserDTO();
		userDTO = userService.getUserProfile(userId);
		
		return ResponseEntity.ok(userDTO);
	}

	@GetMapping("/booking/{userId}")
	public List<BookingDTO> showMyAppointments(@PathVariable("userId") String userId) {

		logger.info("In showMyAppointments method");
		
		List<BookingDTO> bookingDTOList = new ArrayList<>();
		bookingDTOList = bookService.findBookingByUserId(userId);
		return bookingDTOList;
	}

}
