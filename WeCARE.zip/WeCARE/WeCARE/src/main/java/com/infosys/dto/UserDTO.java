package com.infosys.dto;

import java.time.LocalDate;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import com.infosys.entity.UserEntity;

public class UserDTO {
	
	private String userId;
	
	@NotNull(message = "Name cannot be empty")
	@Length(min = 3, max = 50, message = "name should be min 3 and max 50")
	private String name;
	
	@NotNull(message = "Password cannot be empty")
	@Length(min = 5, max = 10, message = "password should be min 5 and max 10")
	private String password;
	
	private char gender;
	private LocalDate dateOfBirth;
	
	@NotNull(message = "Mobile no can't be blank")
	@Digits(integer = 10, message = "min and max should be 10", fraction = 0)
	private long mobileNumber;
	
	@Email(message ="Enter valid email id")
	private String email;
	
	@NotNull(message = "Pincode can't be blank")
	@Digits(integer = 6, message = "min and max should be 6", fraction = 0)
	private int pincode;
	
	@NotNull(message = "City can't be blank")
	@Length(min = 3, max = 20, message = "city should be min 3 and max 20")
	private String city;
	
	@NotNull(message = "State can't be blank")
	@Length(min = 3, max = 20, message = "state should be min 3 and max 20")
	private String state;
	
	@NotNull(message = "Country can't be blank")
	@Length(min = 3, max = 20, message = "country should be min 3 and max 20")
	private String country;

	public UserDTO() {}
	public UserDTO(String userId, String name, String password, char gender, LocalDate dateOfBirth, long mobileNumber,
			String email, int pincode, String city, String state, String country) {
		super();
		this.userId = userId;
		this.name = name;
		this.password = password;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.pincode = pincode;
		this.city = city;
		this.state = state;
		this.country = country;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	public static UserEntity prepareUserDTO(UserDTO userDTO)
	{
		UserEntity userEntity = new UserEntity();
		userEntity.setUserId(userDTO.getUserId());
		userEntity.setName(userDTO.getName());
		userEntity.setPassword(userDTO.getPassword());
		userEntity.setEmail(userDTO.getEmail());
		userEntity.setCity(userDTO.getCity());
		userEntity.setCountry(userDTO.getCountry());
		userEntity.setDateOfBirth(userDTO.getDateOfBirth());
		userEntity.setGender(userDTO.getGender());
		userEntity.setMobileNumber(userDTO.getMobileNumber());
		userEntity.setPincode(userDTO.getPincode());
		userEntity.setState(userDTO.getState());
		
		return userEntity;
	}

	@Override
	public String toString() {
		return "UserDTO [userId=" + userId + ", name=" + name + ", password=" + password + ", gender=" + gender
				+ ", dateOfBirth=" + dateOfBirth + ", mobileNumber=" + mobileNumber + ", email=" + email + ", pincode="
				+ pincode + ", city=" + city + ", state=" + state + ", country=" + country + "]";
	}

	
	
}
