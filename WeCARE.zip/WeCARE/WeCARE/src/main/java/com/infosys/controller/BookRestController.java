package com.infosys.controller;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.BookingDTO;
import com.infosys.exception.WecareException;
import com.infosys.service.BookService;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BookRestController {
	
	private static Logger logger = LoggerFactory.getLogger(BookRestController.class);
	
	@Autowired
	private BookService bookService;
	
	@Value( "${status.not.found}" ) private String statusNotFound;
	
	@PostMapping("/{userId}/booking/{coachId}")
	public ResponseEntity<Boolean> bookAppointment(@PathVariable ("userId")String userId, @PathVariable ("coachId") String coachId, 
			@RequestBody BookingDTO bookingDTO) throws WecareException{
//			@RequestBody String slot, @RequestBody LocalDate dateOfAppointment) throws WecareException{
		
		logger.info("In bookAppointment method");
		boolean response = false;
		response = bookService.bookAppointment(userId, coachId, bookingDTO.getAppointmentDate(), bookingDTO.getSlot());
		
		if (response == false){
			throw new WecareException(statusNotFound);
		}
		return ResponseEntity.ok(response);
	}
	
	@PutMapping("/booking/{bookingId}")
	public ResponseEntity<Boolean> rescheduleAppointment(@PathVariable ("bookingId") Integer bookingId, 
			@RequestBody BookingDTO bookingDTO) throws WecareException {
//			@RequestBody String slot, @RequestBody LocalDate dateOfAppointment) throws WecareException{
		
		logger.info("In rescheduleAppointment method");
		boolean response = false;
		response = bookService.rescheduleAppointment(bookingId, bookingDTO.getAppointmentDate(),bookingDTO.getSlot());
		
		if (response == false){
			throw new WecareException(statusNotFound);
		}
		
		return ResponseEntity.ok(response);
		
	}
	
	@DeleteMapping("/booking/{bookingId}")
	public ResponseEntity<?> cancelAppointment(@PathVariable ("bookingId") Integer bookingId) {
		
		logger.info("In cancelAppointment method");
		bookService.cancelAppointment(bookingId);
		return ResponseEntity.ok(null);
	}

}
