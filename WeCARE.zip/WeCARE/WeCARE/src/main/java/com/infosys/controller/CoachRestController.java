package com.infosys.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.BookingDTO;
import com.infosys.dto.CoachDTO;
import com.infosys.dto.ErrorMessage;
import com.infosys.dto.LoginDTO;
import com.infosys.exception.WecareException;
import com.infosys.service.BookService;
import com.infosys.service.CoachService;

@RestController
@RequestMapping("/coaches")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CoachRestController {
	
	private static Logger logger = LoggerFactory.getLogger(CoachRestController.class);
	
	@Autowired
	private CoachService coachService;

	@Autowired
	private BookService bookingService;

	@PostMapping
	public ResponseEntity<String> createCoach(@RequestBody CoachDTO coachDTO, Errors error) {
		
		logger.info("In createCoach method");
		
		String response = "";
		if (error.hasErrors()) {
			// collecting the validation errors of all fields together in a String delimited
			// by commas
			response = error.getAllErrors().stream().map(ObjectError::getDefaultMessage)
					.collect(Collectors.joining(","));
			ErrorMessage er = new ErrorMessage();
			er.setMessage(response);
			return ResponseEntity.ok(er.getMessage());
		} else {
			response = coachService.createCoach(coachDTO);
			return ResponseEntity.ok(response);
		}
	}

	@PostMapping("/login")
	public ResponseEntity<Boolean> loginCoach(@RequestBody LoginDTO loginDTO) throws WecareException {
		
		logger.info("In loginCoach method");
		
		boolean response = false;
		
		response = coachService.loginCoach(loginDTO);
		System.out.println(response);
		return ResponseEntity.ok(response);

	}

	@GetMapping("/{coachId}")
	public ResponseEntity<CoachDTO> getCoachProfile(@PathVariable("coachId") String coachId) {
		
		logger.info("In getCoachProfile method");
		CoachDTO coach = new CoachDTO();
		coach = coachService.getCoachProfile(coachId);
		return ResponseEntity.ok(coach);
	}

	@GetMapping("/all")
	public List<CoachDTO> showAllCoaches() {
		
		logger.info("In showAllCoaches method");
		List<CoachDTO> coachDTOList = new ArrayList<>();
		coachDTOList = coachService.showAllCoaches();
		return coachDTOList;
	}

	@GetMapping("/booking/{coachId}")
	public List<BookingDTO> showMySchedule(@PathVariable("coachId") String coachId) {
		
		logger.info("In showMySchedule method");
		
		List<BookingDTO> bookingDTOList = new ArrayList<>();
		bookingDTOList = bookingService.findBookingByCoachId(coachId);
		return bookingDTOList;
	}

}
