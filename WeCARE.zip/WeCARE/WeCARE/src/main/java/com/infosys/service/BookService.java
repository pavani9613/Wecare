package com.infosys.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.infosys.dto.BookingDTO;
import com.infosys.entity.BookingEntity;
import com.infosys.entity.CoachEntity;
import com.infosys.entity.UserEntity;
import com.infosys.exception.WecareException;
import com.infosys.repository.BookRepository;
import com.infosys.repository.CoachRepository;
import com.infosys.repository.UserRepository;

@Service
public class BookService {

	private static Logger logger = LoggerFactory.getLogger(BookService.class);

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CoachRepository coachRepository;

	@Value("${booking.already.exists}")
	private String bookingExists;

	public boolean bookAppointment(String userId, String coachId, LocalDate appointmentDate, String slot)
			throws WecareException {

		logger.info("In bookAppointment method");

		List<BookingEntity> bookings = new ArrayList<>();
		bookings = bookRepository.findBookingByUserId(userId,LocalDate.now());
		System.out.println(bookings);
		boolean response = false;

		if (bookings.isEmpty()) {
			BookingEntity book = new BookingEntity();
			book.setCoachId(coachId);
			book.setUserId(userId);
			book.setAppointmentDate(appointmentDate);
			book.setSlot(slot);
			System.out.println(book);
			bookRepository.save(book);
			response = true;
			return response;
		}

		int count = 0;
		for (BookingEntity bookingEntity : bookings) {
//			if (!(userId.equals(bookingEntity.getUserId()))
//					|| !(appointmentDate.equals(bookingEntity.getAppointmentDate()))
//					|| !(slot.equals(bookingEntity.getSlot()))) {
			if (((appointmentDate.equals(bookingEntity.getAppointmentDate()))
    			&& (slot.equals(bookingEntity.getSlot())))) {

				count++;
			}

		}
		if (count == 0) 
		{
			BookingEntity book = new BookingEntity();
			book.setCoachId(coachId);
			book.setUserId(userId);
			book.setAppointmentDate(appointmentDate);
			book.setSlot(slot);
			bookRepository.save(book);
			response = true;

			Optional<UserEntity> user;
			user = userRepository.findByUserId(userId);

			Optional<CoachEntity> coach;
			coach = coachRepository.findByCoachId(coachId);

			// new MailUtility().sendSchedulingEmail(user.get().getName(),
			// coach.get().getName(), user.get().getEmail(),book.getBookingId(),
			// book.getSlot(), book.getAppointmentDate());
			
			return response;
		}
		{
			throw new WecareException(bookingExists);
		}

	}

	public boolean rescheduleAppointment(Integer bookingId, LocalDate appointmentDate, String slot)
			throws WecareException {

		logger.info("In rescheduleAppointment method");

		boolean response = false;
		BookingEntity book;
		List<BookingEntity> bookings = new ArrayList<>();

		book = bookRepository.getOne(bookingId);
		bookings = bookRepository.findBookingByUserId(book.getUserId(),LocalDate.now());
		int count = 0;

		for (BookingEntity bookingEntity : bookings) {
			if (bookingEntity.getAppointmentDate().equals(appointmentDate)
					&& bookingEntity.getSlot().equals(slot)) {
				count++;
			}

		}

		System.out.println("count :" +count);
		if (count == 0) {
			BookingEntity booking = new BookingEntity();
			// booking.setBookingId(bookingEntity.getBookingId());
			booking.setCoachId(book.getCoachId());
			booking.setUserId(book.getUserId());
			booking.setAppointmentDate(appointmentDate);
			booking.setSlot(slot);
			bookRepository.save(booking);
			response = true;
//
//			Optional<UserEntity> user;
//			user = userRepository.findByUserId(book.getUserId());
//
//			Optional<CoachEntity> coach;
//			coach = coachRepository.findByCoachId(book.getCoachId());

			// new MailUtility().sendSchedulingEmail(user.get().getName(),
			// coach.get().getName(), user.get().getEmail(),book.getBookingId(),
			// book.getSlot(), book.getAppointmentDate());
			
			return response;
		} else {
			throw new WecareException(bookingExists);
		}

		
	}

	public void cancelAppointment(Integer bookingId) {

		logger.info("In cancelAppointment method");

		Optional<BookingEntity> book;
		book = bookRepository.findById(bookingId);
		if (book.isPresent()) {
			bookRepository.deleteById(bookingId);

			Optional<UserEntity> user;
			user = userRepository.findByUserId(book.get().getUserId());

			Optional<CoachEntity> coach;
			coach = coachRepository.findByCoachId(book.get().getCoachId());

			// new MailUtility().sendCancellingEmail(user.get().getName(),
			// coach.get().getName(),
			// user.get().getEmail(), book.get().getBookingId(),book.get().getSlot(),
			// book.get().getAppointmentDate());
		}

	}

	public BookingDTO findByBookingId(Integer bookingId) {

		logger.info("In findByBookingId method");

		BookingEntity book;

		book = bookRepository.getOne(bookingId);
		return book.prepareBookingDTO(book);
	}

	public List<BookingDTO> findBookingByUserId(String userId) {

		logger.info("In findBookingByUserId method");

		List<BookingEntity> bookings = new ArrayList<>();
		List<BookingDTO> bookingDTOList = new ArrayList<>();

		bookings = bookRepository.findBookingByUserId(userId, LocalDate.now());

		for (BookingEntity bookingEntity : bookings) {
			bookingDTOList.add(bookingEntity.prepareBookingDTO(bookingEntity));
		}
		return bookingDTOList;
	}

	public List<BookingDTO> findBookingByCoachId(String coachId) {

		logger.info("In findBookingByCoachId method");

		List<BookingEntity> bookings = new ArrayList<>();
		List<BookingDTO> bookingDTOList = new ArrayList<>();

		bookings = bookRepository.findBookingByCoachId(coachId, LocalDate.now());

		for (BookingEntity bookingEntity : bookings) {
			bookingDTOList.add(bookingEntity.prepareBookingDTO(bookingEntity));
		}
		return bookingDTOList;
	}

}
