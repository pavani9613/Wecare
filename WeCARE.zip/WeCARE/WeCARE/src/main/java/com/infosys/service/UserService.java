package com.infosys.service;

import java.util.Optional;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.infosys.controller.BookRestController;
import com.infosys.dto.LoginDTO;
import com.infosys.dto.UserDTO;
import com.infosys.entity.UserEntity;
import com.infosys.exception.WecareException;
import com.infosys.repository.UserRepository;
import com.infosys.utility.UserIdGenerator;

@Service
public class UserService {
	
	private static Logger logger = LoggerFactory.getLogger(UserService.class);
	
	@Autowired
	private UserRepository userRepository;
	
	@Value( "${user.not.found}" ) private String userNotFound;
	
	public String createUser(UserDTO userDTO) {
		
		logger.info("In createUser method");
		SharedSessionContractImplementor sharedSessionContractImplementor = null;
		Object object = null;
		userDTO.setUserId(new UserIdGenerator().generate(sharedSessionContractImplementor,object).toString());
		userRepository.save(userDTO.prepareUserDTO(userDTO));
		return userDTO.getUserId();
	}
	
	public boolean loginUser(LoginDTO loginDTO) throws  WecareException{
		
		logger.info("In loginUser method");
		
		boolean response = false;
		Optional<UserEntity> userEntity;
		System.out.println("UserId " +loginDTO.getId());
		userEntity = userRepository.findByUserId(loginDTO.getId());
		
		if (userEntity.get().getPassword().equals(loginDTO.getPassword())) {
			response = true;
		}
		else {
			throw new WecareException(userNotFound);
		}
		
		return response;
		
	}
	
	public UserDTO getUserProfile(String userId) {
		
		logger.info("In getUserProfile method");
		
		Optional<UserEntity> userEntity;
		UserDTO userDTO;
		
		userEntity = userRepository.findByUserId(userId);
		userDTO = userEntity.get().prepareUserDTO(userEntity.get());
		
		return userDTO;
	}

}
