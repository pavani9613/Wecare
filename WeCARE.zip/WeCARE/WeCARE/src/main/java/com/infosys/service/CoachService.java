package com.infosys.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.infosys.controller.BookRestController;
import com.infosys.dto.CoachDTO;
import com.infosys.dto.LoginDTO;
import com.infosys.entity.CoachEntity;
import com.infosys.exception.WecareException;
import com.infosys.repository.CoachRepository;
import com.infosys.utility.CoachIdGenerator;

@Service
public class CoachService {
	
	private static Logger logger = LoggerFactory.getLogger(CoachService.class);
	
	@Value( "${coach.not.found}" ) private String coahNotFound;
	
	@Autowired
	private CoachRepository coachRepository;
	
	public String createCoach(CoachDTO coachDTO) {
		logger.info("In createCoach method");
		SharedSessionContractImplementor sharedSessionContractImplementor = null;
		Object object = null;
		coachDTO.setCoachId(new CoachIdGenerator().generate(sharedSessionContractImplementor,object).toString());
		coachRepository.save(coachDTO.prepareCoachEntity(coachDTO));
		return coachDTO.getCoachId();
	}
	
	public boolean loginCoach(LoginDTO loginDTO) throws WecareException {
		logger.info("In loginCoach method");
		
		boolean response = false;
		CoachEntity coachEntity;
		System.out.println("hi");
		System.out.println("CoachId " + loginDTO.getId());
		
		coachEntity = coachRepository.findByCoachId(loginDTO.getId()).get();
		
		if (coachEntity.getPassword().equals(loginDTO.getPassword())) {
			response = true;
			System.out.println("Coach entity "+ coachEntity);
		}
		else {
			throw new WecareException(coahNotFound);
		//	throw new WecareException("Coach not found");
		}
		
		return response;
	}

	public CoachDTO getCoachProfile(String coachId) {
		
		logger.info("In getCoachProfile method");
		
		Optional<CoachEntity> coachEntity;
		CoachDTO coachDTO;
		
		coachEntity = coachRepository.findByCoachId(coachId);
		coachDTO = coachEntity.get().prepareCoachDTO(coachEntity.get());
		
		return coachDTO;
	}
	
	public List<CoachDTO> showAllCoaches() {
		logger.info("In showAllCoaches method");
		List<CoachDTO> coachDTOList = new ArrayList<>();
		List<CoachEntity> coachList = new ArrayList<>();
		
		coachList = coachRepository.findAll();
		
		for (CoachEntity coachEntity : coachList) {
			coachDTOList.add(coachEntity.prepareCoachDTO(coachEntity));
		}
		return coachDTOList;
	}
}

