package com.infosys.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infosys.entity.BookingEntity;

public interface BookRepository extends JpaRepository<BookingEntity, Integer> {
	
	 public Optional<BookingEntity> findByUserId(String userId);
	 
	 @Query("select book from BookingEntity book where book.userId = ?1 and book.appointmentDate > ?2")
	 public List<BookingEntity> findBookingByUserId(String userId, LocalDate today);
	
	 @Query("select book from BookingEntity book where book.coachId = ?1 and book.appointmentDate > ?2")
	 public List<BookingEntity> findBookingByCoachId(String coachId, LocalDate today);
	 
     @Query("select book from BookingEntity book where book.userId = ?1 and book.appointmentDate = ?2 and book.slot = ?3")
//	 @Query("select book from BookingEntity book")
 	 public List<BookingEntity> findAllBookings(String userId, LocalDate appointmentDate, String slot);
}
